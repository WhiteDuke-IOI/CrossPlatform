﻿IF OBJECT_ID(N'[__EFMigrationsHistory]') IS NULL
BEGIN
    CREATE TABLE [__EFMigrationsHistory] (
        [MigrationId] nvarchar(150) NOT NULL,
        [ProductVersion] nvarchar(32) NOT NULL,
        CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY ([MigrationId])
    );
END;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241018142434_InitialCreate'
)
BEGIN
    CREATE TABLE [Flights] (
        [Number] int NOT NULL IDENTITY,
        [Route] nvarchar(max) NOT NULL,
        [CityFrom] nvarchar(max) NOT NULL,
        [CityTo] nvarchar(max) NOT NULL,
        [DapartingTime] datetime2 NOT NULL,
        [ArrivalTime] datetime2 NOT NULL,
        CONSTRAINT [PK_Flights] PRIMARY KEY ([Number])
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241018142434_InitialCreate'
)
BEGIN
    CREATE TABLE [Passengers] (
        [ID] int NOT NULL IDENTITY,
        [Name] nvarchar(max) NOT NULL,
        [Surname] nvarchar(max) NOT NULL,
        [Loyalty] nvarchar(max) NOT NULL,
        CONSTRAINT [PK_Passengers] PRIMARY KEY ([ID])
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241018142434_InitialCreate'
)
BEGIN
    CREATE TABLE [FlightPassenger] (
        [FlightsNumber] int NOT NULL,
        [PassengerID] int NOT NULL,
        CONSTRAINT [PK_FlightPassenger] PRIMARY KEY ([FlightsNumber], [PassengerID]),
        CONSTRAINT [FK_FlightPassenger_Flights_FlightsNumber] FOREIGN KEY ([FlightsNumber]) REFERENCES [Flights] ([Number]) ON DELETE CASCADE,
        CONSTRAINT [FK_FlightPassenger_Passengers_PassengerID] FOREIGN KEY ([PassengerID]) REFERENCES [Passengers] ([ID]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241018142434_InitialCreate'
)
BEGIN
    CREATE INDEX [IX_FlightPassenger_PassengerID] ON [FlightPassenger] ([PassengerID]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20241018142434_InitialCreate'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20241018142434_InitialCreate', N'8.0.10');
END;
GO

COMMIT;
GO

